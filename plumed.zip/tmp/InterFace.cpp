/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   Copyright (c) 2011-2016 The plumed team
   (see the PEOPLE file at the root of the distribution for a list of names)

   See http://www.plumed.org for more information.

   This file is part of plumed, version 2.

   plumed is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   plumed is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with plumed.  If not, see <http://www.gnu.org/licenses/>.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
// #include <iostream> // (T)
// #include <fstream>  // (T)
#include "colvar/Colvar.h"
#include "colvar/ActionRegister.h"
#include "tools/Communicator.h"
#include "tools/Tools.h"
#include "tools/IFile.h"

#include <string>
#include <math.h>

using namespace std;

namespace PLMD{
namespace colvar{

//+PLUMEDOC COLVAR INTERFACE
/*

\plumedfile
LOAD FILE=InterFace.cpp

# Define groups for the CV
C: GROUP ATOMS=1-2400:8
W: GROUP ATOMS=2401-11400

INTERFACE ...
 LABEL=ma
 CENTER=C
 WATER=W
 R0CUT=1.0
 RWCUT=1=0.4
 R_0=0.5
 R_W=0.3
 C_0=5
 XI_0=0.2
... INTERFACE

PRINT STRIDE=1  ARG=* FILE=COLVAR
\endplumedfile

*/
//+ENDPLUMEDOC

class InterFace : public Colvar {
bool pbc, serial;
  vector<AtomNumber> center_lista, water_lista;
  std::vector<PLMD::AtomNumber> atomsToRequest;
  double r0cut;                    // (T)
  double rwcut;                    // (T)
  double r0, invr0, invr0_6;       // (T)
  double rw, invrw, invrw_6;       // (T)
  double c0;                       // (T)
  double xi0;                      // (T)

public:
  explicit InterFace(const ActionOptions&);
  virtual void calculate();
  static void registerKeywords( Keywords& keys );
};

PLUMED_REGISTER_ACTION(InterFace,"INTERFACE")

void InterFace::registerKeywords( Keywords& keys ){
  Colvar::registerKeywords(keys);
  keys.addFlag("SERIAL",false,"Perform the calculation in serial - for debug purpose");
  keys.add("atoms","CENTER","Center atoms");
  keys.add("atoms","WATER","Water atoms"); // (T)
  keys.add("compulsory","R0CUT","1.0","Maximum distance for being neighbor (in first shell)");
  keys.add("compulsory","RWCUT","0.4","Maximum distance for being neighbor (in first shell)");
  keys.add("compulsory","R_0","0.5","The r_s parameter of the crystal-like molecules of solute");
  keys.add("compulsory","R_W","0.3","The r_w parameter of the interfacial water molecules");
  keys.add("compulsory","C_0","5.0","Minimum number of neighboring solute molecule to become crystal-like");
  keys.add("compulsory","XI_0","0.2","After 0.5*xi0, we assume 0.5*xi=0.5*(tanh(cn-c0)+1) to be zero.");
}

InterFace::InterFace(const ActionOptions&ao):
PLUMED_COLVAR_INIT(ao),
pbc(true),
serial(false)
{

  parseFlag("SERIAL",serial);

  parseAtomList("CENTER",center_lista);
  parseAtomList("WATER",water_lista);
  
  bool nopbc=!pbc;
  parseFlag("NOPBC",nopbc);
  pbc=!nopbc;

  if(pbc) log.printf("  using periodic boundary conditions\n");
  else    log.printf("  without periodic boundary conditions\n");

  addValueWithDerivatives(); setNotPeriodic();

  parse("R0CUT",r0cut);
  log.printf("  The neighbor (in the first shell) is defined within 0 and %f \n", r0cut);

  parse("RWCUT",rwcut);
  log.printf("  The neighbor (in the first shell) of solvent is defined within 0 and %f \n", rwcut);

  parse("R_0",r0);
  if(r0<=0.0) error("R_0 should be explicitly specified and positive");
  log.printf("  The molecules in contact are defined within 0 and %f \n", r0);
  invr0 = 1.0/r0;
  invr0_6=pow(invr0,6);

  parse("R_W",rw);
  if(rw<=0.0) error("R_W should be explicitly specified and positive");
  log.printf("  The molecules in contact are defined within 0 and %f \n", rw);
  invrw = 1.0/rw;
  invrw_6=pow(invrw,6);

  parse("C_0",c0);
  log.printf("  The c0 parameter is %f \n", c0);

  parse("XI_0",xi0);
  log.printf("  The 0.5*xi_0 parameter is %f \n", xi0);

  checkRead();

  atomsToRequest.reserve ( center_lista.size() + water_lista.size() );                     // (T)
  atomsToRequest.insert (atomsToRequest.end(), center_lista.begin(), center_lista.end() );
  atomsToRequest.insert (atomsToRequest.end(), water_lista.begin(), water_lista.end() );   // (T)
  requestAtoms(atomsToRequest);

}

// calculator
void InterFace::calculate()
{
  // long int step=getStep();               // (T)
  double chi(0.0);                       // (T)

  unsigned nat = getNumberOfAtoms();     // (T) only contain atoms listed in plumed.
  vector<Vector> deriv(nat);             // (T) This will initialized vector with 0 modulo.
  // unsigned num_crystal;                  // (T)


  // ofstream myfile;
  // ofstream uidlFile("step_cw.txt", fstream::in | fstream::out | fstream::app);
  // myfile.open("2.txt");
  // uidlFile << "step cw" << endl;


  if(pbc) makeWhole();
  // Setup parallelization
  unsigned stride = comm.Get_size();
  unsigned rank = comm.Get_rank();

  if(serial){
    stride = 1;
    rank = 0;
  } else {
    stride = comm.Get_size();
    rank = comm.Get_rank();
  }
  

  for(unsigned int i=rank;i<center_lista.size();i+=stride) {

    Vector dcn_dri, dcw_dri;       // (T)

    double cn(0.0);  // cn=cn(i) (T)
    for(unsigned int j=i+1;j<center_lista.size();j+=1) {
      Vector distance;
      if(pbc) distance = pbcDistance(getPosition(i),getPosition(j));
      else distance = delta(getPosition(i),getPosition(j));

      double d = distance.modulo();
      if ( d<r0cut ) {
        // Compute coordination number of i-th urea and derivative of j-th urea to i-th urea
        double d6 = invr0_6*pow(d,6);
        double cn_j = 1/(1+d6);
        cn += cn_j;
        double invvalue = 1/d;
        Vector ddij_dri = -invvalue*distance;
        double dcn_ddij = -6*invvalue*cn_j*cn_j*d6;
        dcn_dri += dcn_ddij*ddij_dri;

      }
    }

    double xi = tanh(cn-c0)+1;
    double half_xi = 0.5*xi;
    double dxi_dcn = 1-xi*xi;
    double half_dxi_dcn = 0.5*dxi_dcn;

    if(xi<xi0) continue;

    double cw(0.0);  // cw=cw(i) (T)
    for(unsigned int k=0;k<water_lista.size();k+=1) {
      unsigned l = k+center_lista.size();  // (T)
      
      Vector distance_w;
      if(pbc) distance_w = pbcDistance(getPosition(i),getPosition(l));
      else distance_w = delta(getPosition(i),getPosition(l));

      double d_w = distance_w.modulo();
      if ( d_w<rwcut) {
        // Compute number of waters around i-th urea and derivative of l-th water to i-th urea
        double d6_w = invrw_6*pow(d_w,6);
        double cw_l = 1/(1+d6_w);
        cw += cw_l;
        double invvalue_w = 1/d_w;
        Vector ddil_dri = -invvalue_w*distance_w;
        double dcw_ddil = -6*invvalue_w*cw_l*cw_l*d6_w;
        dcw_dri += dcw_ddil*ddil_dri;

        // Compute the contribution of derivative of i-th urea to l-th water
        Vector ddil_drl = invvalue_w*distance_w;
        deriv[l] += half_xi*dcw_ddil*ddil_drl;
      }
    }

    chi += half_xi*cw;

    // Compute total derivative of i-th urea
    deriv[i] += half_dxi_dcn*dcn_dri*cw + half_xi*dcw_dri;


    // Multiply the derivatives of j-th urea by dxi_dcn. Since it is only dependent on i we can calculate it here.
    for(unsigned int j=i+1;j<center_lista.size();j+=1) {
      Vector distance;
      if(pbc) distance = pbcDistance(getPosition(i),getPosition(j));
      else distance = delta(getPosition(i),getPosition(j));
      
      double d = distance.modulo();
      if ( d<r0cut ) {
        // Compute the contribution of derivative of i-th urea to j-th urea
        double d6 = invr0_6*pow(d,6);
        double cn_j = 1/(1+d6);
        double invvalue = 1/d;
        Vector ddij_drj = invvalue*distance;
        double dcn_ddij = -6*invvalue*cn_j*cn_j*d6;

        deriv[j] += half_dxi_dcn*dcn_ddij*ddij_drj*cw;

      }
    }


    // cout << "cn: " << cn << endl;
    // cout << "water: " << cw << endl;
    // myfile << cw << " " << endl;
    // cout << "Step:" << step << endl;
    // uidlFile << step << " " << cw << " " << endl;


  }
  
  if(!serial){
    comm.Sum(chi);
    for(unsigned i=0;i<nat;++i) comm.Sum(deriv[i]);
  }

  
  // Assign output quantities
  Tensor virial;                                     // (T)
  for(unsigned i=0;i<nat;++i){
    setAtomsDerivatives(i, deriv[i]);                // (T)
    virial -= Tensor(getPosition(i), deriv[i]);      // (T)
  }
  setValue(chi);                                     // (T)
  setBoxDerivatives(virial);                         // (T)
  // uidlFile.close();                                  // (T)


}





}
}

